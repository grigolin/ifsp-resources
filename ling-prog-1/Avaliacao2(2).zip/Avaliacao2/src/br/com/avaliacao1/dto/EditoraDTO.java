/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.avaliacao1.dto;

/**
 *
 * @author guilherme
 */
public class EditoraDTO {

    private String nome_editora, cnpj_editora, sede_editora;
    private int id_editora;

    public String getNome_editora() {
        return nome_editora;
    }

    public void setNome_editora(String nome_editora) {
        this.nome_editora = nome_editora;
    }

    public String getCnpj_editora() {
        return cnpj_editora;
    }

    public void setCnpj_editora(String cnpj_editora) {
        this.cnpj_editora = cnpj_editora;
    }

    public String getSede_editora() {
        return sede_editora;
    }

    public void setSede_editora(String sede_editora) {
        this.sede_editora = sede_editora;
    }

    public int getId_editora() {
        return id_editora;
    }

    public void setId_editora(int id_editora) {
        this.id_editora = id_editora;
    }

}
