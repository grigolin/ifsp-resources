/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.avaliacao1.dto;

import java.util.Date;

/**
 *
 * @author guilherme
 */
public class EmprestimoDTO {

    private int id_emprestimo;
    private Date data_inicio_emprestimo, data_fim_emprestimo;

    public int getId_emprestimo() {
        return id_emprestimo;
    }

    public void setId_emprestimo(int id_emprestimo) {
        this.id_emprestimo = id_emprestimo;
    }

    public Date getData_inicio_emprestimo() {
        return data_inicio_emprestimo;
    }

    public void setData_inicio_emprestimo(Date data_inicio_emprestimo) {
        this.data_inicio_emprestimo = data_inicio_emprestimo;
    }

    public Date getData_fim_emprestimo() {
        return data_fim_emprestimo;
    }

    public void setData_fim_emprestimo(Date data_fim_emprestimo) {
        this.data_fim_emprestimo = data_fim_emprestimo;
    }

    

}
