<!DOCTYPE html>
<html>
<head>
    <title><?php echo "Guilherme";?>
</title>
</head>
<body>
    <h1><?php echo "Guilherme!";?></h1>
    <p><a href='../hello/'>Hello</a></p>
</body>
</html>