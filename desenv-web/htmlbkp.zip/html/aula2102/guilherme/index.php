<?php
    header("Location: ./gui.php");