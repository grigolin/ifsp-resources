<?php
	phpinfo();

