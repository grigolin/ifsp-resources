<?php
header("Location: hello.php");
?>