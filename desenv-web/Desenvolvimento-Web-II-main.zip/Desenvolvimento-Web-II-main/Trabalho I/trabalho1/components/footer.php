<footer class="bg-dark text-white text-center py-3 mt-auto">
    <p>&copy; Trabalho T1 - VTPDWE2 & VTPISRV.</p>
    <hr>
    <p>Alexandre Augusto dos Santos Feltrin</p>
    <p>alexandreaug21@gmail.com</p>
</footer>