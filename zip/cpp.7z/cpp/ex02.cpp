#include <iostream>
using namespace std;

int main(){
    cout << "Meu nome é: Guilherme" << "\n";
    cout << "Sou do curso de Sistemas de Informação." << "\n";
    cout << "Estou no primeiro ano." << "\n";
    cout << "Gosto de programação!!!" << "\n";

    return 0;
}