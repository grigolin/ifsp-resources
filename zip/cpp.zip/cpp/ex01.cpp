#include <iostream>
using namespace std;

int main(){
    cout << "Sou calouro de BSI!!!!";
    return 0;
}